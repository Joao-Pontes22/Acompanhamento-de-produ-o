class valueSector:
    def __init__(self, sector_name: str):
        self.sector_name = sector_name.upper()