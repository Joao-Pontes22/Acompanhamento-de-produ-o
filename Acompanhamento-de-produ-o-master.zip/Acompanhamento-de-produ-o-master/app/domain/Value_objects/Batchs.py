class ValueBatchs:
    def __init__(self, batch: str):
        self.batch = batch.upper()