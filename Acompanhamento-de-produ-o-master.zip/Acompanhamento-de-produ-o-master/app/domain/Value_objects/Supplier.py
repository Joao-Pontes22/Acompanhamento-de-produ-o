class value_Supplier:
    def __init__(self,supplier):
        self.name = supplier.upper()