
class valueStatus:
    def __init__(self, status: str):
        self.status = status.upper()
