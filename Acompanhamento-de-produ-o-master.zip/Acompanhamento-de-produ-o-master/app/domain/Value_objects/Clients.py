class value_Client:
    def __init__(self, client):
        self.name = client.upper()