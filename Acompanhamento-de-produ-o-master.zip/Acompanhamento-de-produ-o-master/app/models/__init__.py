# This file makes the models directory a Python package.
from app.models.Assembly_production import AssemblyProduction
from app.models.Clients import Clients
from app.models.ComponentsAndParts import ComponentsAndParts
from app.models.Employers import Employers
from app.models.Machines import Machines
from app.models.Machining_production import MachiningProduction
from app.models.Assembly_production import AssemblyProduction
from app.models.Movimentations import movimentations
from app.models.Relation import Relation
from app.models.Scraps import Scraps
from app.models.Sectors import Sectors
from app.models.Setup import Setup
