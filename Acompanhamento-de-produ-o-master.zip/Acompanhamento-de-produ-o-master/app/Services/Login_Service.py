#Date Time
from datetime import datetime, timedelta, timezone
#Schemas
from app.Schemas.Login_Schema import LoginSchema
#Value Objects
from app.domain.Value_objects.Emp_id import ValueEmpID
#Settings
from app.core.Settings.Settings import ACCESS_TOKEN_EXPIRE_MINUTES, ALGORITHM, SECRET_KEY, bcrypt_context
#JWT
from jose import jwt
#FastAPI
from fastapi.security import OAuth2PasswordRequestForm
#Repository
from app.repositories.Employers_repository import EmployersRepository
#Exceptions
from app.domain.Exceptions import NotFoundException, IncorrectPasswordException

class LoginService:
    def __init__(self, repo:EmployersRepository):
        self.repo = repo

    def login_in(self, scheme:LoginSchema):

        employer = self.repo.get_by_emp_id(emp_id=scheme.emp_id)
        if not employer:
            raise NotFoundException("Employer")
        
        if not bcrypt_context.verify(scheme.password, employer.password):
            raise IncorrectPasswordException()
        
        class_acces_token  = create_token(employerID=employer.ID)

        acces_token = class_acces_token.create_access_token()
        refresh_token= class_acces_token.create_refresh_token()

        return {"access_token": acces_token,
                "refresh_token": refresh_token,
                "token_type": "bearer"}
    
    def login_form_in(self, scheme:OAuth2PasswordRequestForm):

        value_emp_id = ValueEmpID(emp_id=scheme.username)
        employer = self.repo.get_by_emp_id(emp_id=value_emp_id.emp_id)
        if not employer:
            raise NotFoundException("Employer")
        
        if not bcrypt_context.verify(scheme.password, employer.password):
            raise IncorrectPasswordException()
        
        class_acces_token  = create_token(employerID=employer.ID)
        access_token = class_acces_token.create_access_token()

        return {"access_token": access_token,
                "token_type": "bearer"}
    
    def refresh_token(self, employer_id:int):
        class_acces_token = create_token(employerID=employer_id)
        access_token = class_acces_token.create_access_token()
        return {"access_token": access_token,
                "token_type": "bearer"}
    
class create_token:
    def __init__(self, employerID):
        self.employerID = employerID

    def create_access_token(self):
        expiration_date = datetime.now(timezone.utc) + timedelta(
            minutes=int(ACCESS_TOKEN_EXPIRE_MINUTES)
        )

        payload = {
            "sub": str(self.employerID),
            "type": "access",
            "exp": expiration_date,
        }

        return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

    def create_refresh_token(self):
        expiration_date = datetime.now(timezone.utc) + timedelta(days=7)

        payload = {
            "sub": str(self.employerID),
            "type": "refresh",
            "exp": expiration_date,
        }

        return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

        